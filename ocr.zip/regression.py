import numpy as np
import subprocess

def d(x, y):
	return sum([(x[i] - y[i]) ** 2 for i in range(len(x))])

with open('./inputs/optdigits.tra', 'r') as trainingFile:
	trainingData = [] # nagy matrix
	labels = [] # y
	a = int(input('Num1: '))
	b = int(input('Num2: '))
	for line in trainingFile:
		line = line.strip().split(',')
		label = int(line[-1])
		line[-1] = '1'
		pixels = tuple(map(int, line))

		if label == a or label == b:
			trainingData.append(pixels)
			labels.append(1 if label == a else -1)

	with open('octave-input-matrix.m', 'w+') as octIn:
		octIn.write(str(trainingData).replace('[', '').replace('(', '').replace('),', '\n').replace(']', ''))
	with open('octave-input-labels.m', 'w+') as octIn:
		octIn.write(str(labels).replace('[', '').replace('(', '').replace('),', '\n').replace(']', '').replace(',', '\n'))

	subprocess.call(['./run-octave.sh'])
	
	with open('w.txt', 'r') as octOut:
		[octOut.readline() for i in range(5)]
		w = [float(x) for x in octOut.read().strip().split('\n')]
	

	with open('./inputs/optdigits.tes', 'r') as testFile:
		toTestVector = []
		toTestLabel = []
		for line in testFile:
			line = [float(x) for x in line.strip().split(',')]
			label = line[-1]
			if label == a or label == b:
				line[-1] = 1.0
				toTestVector.append(line)
				toTestLabel.append(1 if label == a else -1)

		countGood = 0
		for i in range(len(toTestVector)):
			guess = np.matmul(toTestVector[i], w)
			if guess * toTestLabel[i] > 0:
				countGood += 1

		print(countGood / len(toTestVector))


