#!/bin/bash

octave --silent --eval octave.m