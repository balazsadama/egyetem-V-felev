function [rv] = main (argv)
  X = csvread("octave-input-matrix.m");
	y = csvread("octave-input-labels.m");

	lambda = 0.1;
	xT = X';
	w = inv((xT * X + lambda * eye(columns(X)))) * xT * y;
  
	save('w.txt', 'w');
	rv = 0;
  return;
endfunction

main (argv);