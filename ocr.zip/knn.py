# minden dontesre megnezzuk az osszes tanulasi adatot
from collections import Counter
k = 5

with open('./inputs/optdigits.tra', 'r') as trainingFile:
	trainingData = {}
	for line in trainingFile:
		line = line.strip().split(',')
		pixels = tuple(map(int, line[0:-1]))
		label = int(line[-1])
		trainingData[pixels] = label

with open('./inputs/optdigits.tes', 'r') as testFile:
	# line = testFile.readline().strip().split(',')
	with open('./outputs/knn.out', 'w') as outputFile:
		correct = 0
		total = 0
		for line in testFile:
			line = line.strip().split(',')
			pixels = tuple(map(int, line[0:-1]))
			label = int(line[-1])

			distances = {}
			for key in trainingData:
				distances[key] = -sum([(a - b)**2 for a,b in zip(pixels, key)])
				# make it negative so i can use most_common cuz i'm lazy
			
			nearestValues = Counter(distances).most_common(k)

			nearestNumbers = [trainingData[key[0]] for key in nearestValues]

			guess = Counter(nearestNumbers).most_common(1)[0][0]

			outputFile.write(str(label) + ' ' + str(guess) + '\n')

			if label == guess:
				correct += 1
			total += 1
		
		outputFile.write('Test error: ' + str((total - correct) / total) + '\n')
		correct = 0
		total = 0
		for vector in trainingData:
			distances = {}
			for key in trainingData:
				distances[key] = -sum([(a - b)**2 for a,b in zip(vector, key)])
				# make it negative so i can use most_common cuz i'm lazy
			
			nearestValues = Counter(distances).most_common(k)

			nearestNumbers = [trainingData[key[0]] for key in nearestValues]

			guess = Counter(nearestNumbers).most_common(1)[0][0]

			outputFile.write(str(label) + ' ' + str(guess) + '\n')

			if trainingData[vector] == guess:
				correct += 1
			total += 1
		outputFile.write('\nTraining error: ' + str((total - correct) / total))