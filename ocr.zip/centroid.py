# pixelenkent atlagolunk
# az osszes 7es minden 0-63 pixelere atlagot szamolunk es lesz "idealis 7es"

# centrumokat elore kiszamoljuk es lementjuk

with open('./inputs/optdigits.tra', 'r') as trainingFile:
	trainingData = [[] for i in range(10)]
	for line in trainingFile:
		line = line.strip().split(',')
		pixels = tuple(map(int, line[0:-1]))
		label = int(line[-1])
		trainingData[label].append(pixels)

	centroids = []
	for item in trainingData:
		n = len(item)
		avg = [sum( a[i] for a in item) / n for i in range(64)]
		centroids.append(avg)

with open('./inputs/optdigits.tes', 'r') as testFile:
	with open('./outputs/centroid.out', 'w') as outputFile:
		correct = 0
		total = 0

		for line in testFile:
			line = line.strip().split(',')
			pixels = tuple(map(int, line[0:-1]))
			label = int(line[-1])

			distances = [ sum([(pixels[i] - c[i]) ** 2 for i in range(64)]) for c in centroids]
			guess = distances.index(min(distances))

			outputFile.write(str(label) + ' ' + str(guess) + '\n')
			
			if label == guess:
				correct += 1
			total += 1
		outputFile.write('Test error: ' + str((total - correct) / total))

		correct = 0
		total = 0

		with open('./inputs/optdigits.tra', 'r') as trainingFile:
			for line in trainingFile:
				line = line.strip().split(',')
				pixels = tuple(map(int, line[0:-1]))
				label = int(line[-1])
				
				distances = [ sum([(pixels[i] - c[i]) ** 2 for i in range(64)]) for c in centroids]
				guess = distances.index(min(distances))

				# outputFile.write(str(label) + ' ' + str(guess) + '\n')
				
				if label == guess:
					correct += 1
				total += 1
			outputFile.write('\nTraining error: ' + str((total - correct) / total))


	
# with open('./inputs/optdigits.tra', 'r') as trainingFile:
# 	trainingData = [0] * 10
# 	for line in trainingFile:
# 		line = line.strip().split(',')
# 		pixels = tuple(map(int, line[0:-1]))
# 		label = int(line[-1])
# 		trainingData[label].append(pixels)

